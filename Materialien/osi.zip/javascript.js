function showWindow() {
	
	var win = window.open("","","statusbar=no,width=985,height=555,left=0,top=0,scrollbars=no,toolbar=no,menubar=no,location=no,resizable=no");
	
	with(win.document) {
		open();
		write("<html>\n<head>\n<title>oSI - online Simplex Instructor</title>\n</head>\n<body>\n");
		write("<applet\n");   
  		write("code     = \"applet.Assistent\"\n");
		write("archive  = \"simplex.jar\"\n");
  		write("name     = \"Simplex\"\n");  		
  		write("hspace   = \"0\"\n");
  		write("vspace   = \"0\"\n");
  		write("align    = \"middle\">\n");
		write("</applet>");
		write("</body>\n</html>");
		close();
	}
}

function openApplet() {
       f = window.open("StartseiteOSI.html","Simplex","width=990,height=560,left=0,top=0,scrollbars=no,toolbar=no,menubar=no,location=no,resizeable=no");
       f.focus();
}

